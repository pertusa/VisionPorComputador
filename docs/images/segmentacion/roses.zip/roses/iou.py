import cv2 as cv
import numpy as np
import argparse

parser = argparse.ArgumentParser(description = 'Programa para obtener el IoU de dos imágenes')
parser.add_argument('--obtenida', '-o', type=str)
parser.add_argument('--solucion', '-g', type=str)
args = parser.parse_args()

obtenida = cv.imread(args.obtenida, cv.IMREAD_GRAYSCALE)
solucion = cv.imread(args.solucion, cv.IMREAD_GRAYSCALE)

if (obtenida is None) or (solucion is None):
        print ('Error en alguna de las imagenes')
        quit()
  
# Calculamos intersection over union (IoU), es el porcentaje de acierto de nuestro programa 
intersectionAB = cv.countNonZero(obtenida & solucion)
unionAB = cv.countNonZero(obtenida | solucion)
IoU = intersectionAB / unionAB
    
print(IoU)
