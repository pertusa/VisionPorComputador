#!/bin/bash

echo "Calculando resultados de segmentacion"

meanIoU=0
count=0
for i in input/*.png
do
	filename=$(basename "$i")
	n=${filename%.*}

	python roses.py -i $i -o output/${n}.png
	IoU="$(python iou.py -o output/${n}.png -g gt/${n}.png)"

	echo $filename = $IoU
	meanIoU=`echo $meanIoU+$IoU|bc`
	let "count=count+1"
done

echo "-------"
echo -n "Media IoU = "
echo "scale=5; $meanIoU/$count"|bc -l|sed 's/^\./0./'
