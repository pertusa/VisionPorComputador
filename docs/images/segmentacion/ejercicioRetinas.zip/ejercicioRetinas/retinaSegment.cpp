//Afra Maria Pertusa Llopis 20084695Z

#include <opencv2/opencv.hpp>
#include <iostream>
#include <string>

using namespace std;
using namespace cv;

int main(int argc, char *argv[]){
	
	if(argc != 4){				//4 porque son 3 parámetros: imagen, mascara y destino
		 cerr << " Uso: display_image <imagen>" << endl;
		 return -1;
    }
	
	//Abrir la imagen y mascara
	Mat imagen = imread(argv[1]);
	Mat mascara = imread(argv[2], IMREAD_GRAYSCALE);
	
	if(!imagen.data){
		 cerr << "Could not open or find the image." << endl;
		 return -1;
	}
	if(!mascara.data){
		 cerr << "Could not open or find the mask." << endl;
	 	 return -1;
	}
	
    //- - - Calculo del brillo de la imagen
    Scalar brillo = mean(imagen);
     
    //- - - Subir el brillo de las imágenes a 175 (añadimos lo que falte) y bajamos el contraste
    
    imagen = 0.904*(imagen-120) + 120 + (175 - brillo[0]); //0.904
    
    //Separamos los canales - verde
	vector<Mat> channel;
	split(imagen,channel);
    
    //- - - Erosionar la mascara
    Mat mascara2;
    int tm = MORPH_ELLIPSE;
	Mat elm = getStructuringElement(tm,Size(10,10));  
	erode(mascara,mascara2,elm);
     
    //- - - Detectar los bordes
     
    Mat dx, dy, imagen1;
    Sobel(channel[1], dx, CV_32F, 1, 0);
    Sobel(channel[1], dy, CV_32F, 0, 1);
    magnitude(dx, dy, imagen1);
    imagen1.convertTo(imagen1, CV_8UC1);
     
    //- - - Umbralizado global para que e gris sea negro y el blanco blanco
     
    for(int i = 0; i < imagen1.cols; i++){
		 for(int j = 0; j < imagen1.rows; j++){
			 if(imagen1.at<uchar>(i,j) > 31) //Bordes -31
				imagen1.at<uchar>(i,j) = 255;	//Pone a blanco
			 else
				imagen1.at<uchar>(i,j) = 0; //Pone en negro
		}
	}
	
	imagen1 = imagen1 & mascara;
	
	//- - - Eliminar las impurezas blancas
	Mat imagen2;
	Mat el1 = getStructuringElement(MORPH_ELLIPSE,Size(1.5,1.5)); 
	morphologyEx(imagen1,imagen2,MORPH_OPEN,el1);
	imagen2 = imagen2 & mascara2;
	
	//Se cierran los huecos que quedan en las venas
		
	Mat imagen3;
	Mat el2 = getStructuringElement(MORPH_ELLIPSE,Size(5,5));
	morphologyEx(imagen2,imagen3,MORPH_CLOSE,el2);
	imagen3 = imagen3 & mascara2;
	
	//- - - Eliminar las impurezas blancas que quedan
	
	Mat imagen4;
	Mat el3 = getStructuringElement(MORPH_ELLIPSE,Size(3,3));
	morphologyEx(imagen3,imagen4,MORPH_OPEN,el3);
	imagen4 = imagen4 & mascara2;
	
	//- - - Restamos la imagen con el canal
	imagen4 = imagen4 - channel[1];
	
	//- - - Umbralizamos de nuevo porque sale grisáceo.
	threshold(imagen4,imagen4,7,255,CV_THRESH_BINARY);	 //7,255
	imagen4 = imagen4 & mascara2;
	
	imwrite(argv[3],imagen4);
	waitKey(1);
}
