#!/bin/bash

# Compilamos el codigo
echo "Compilando"
make

# Calculamos el resultado
echo "Calculando resultados de segmentacion"
meanIoU=0
count=0
for i in retinas/images/*.tif 
do
	filename=$(basename "$i")
	n=${filename%_*}

	./retinaSegment  $i retinas/mask/${n}_training_mask.tif retinas/output/${n}_training_output.tif
	IoU="$(./iou retinas/output/${n}_training_output.tif retinas/1st_manual/${n}_manual1.tif)"

	echo $filename = $IoU
	meanIoU=`echo $meanIoU+$IoU|bc`
	let "count=count+1"
done

echo "-------"
echo -n "Media IoU = "
echo "scale=5; $meanIoU/$count"|bc -l|sed 's/^\./0./'
