import os
import argparse
import cv2 as cv
from pathlib import Path

""" Cálculo del intersection over union (IoU) para una imagen """
def single_IoU(path_input):

    if len(path_input.split("/")) > 1:
        filename = path_input.split("/")[-1]
    else:
        filename = path_input.split("\\")[-1]
    pass

    # Obtenemos el path de la imagen de destino (tras segmentación):
    path_obtenida = os.path.join('output', filename)

    # Obtenemos el path de la imagen objetivo:
    path_objetivo = os.path.join('gt', filename)

    # Obtenemos la segmentación:
    try:
        line = 'python roses.py -i {} -o {}'.format(path_input, path_obtenida)
    except:
        line = 'python3 roses.py -i {} -o {}'.format(path_input, path_obtenida)
    os.system(line)

    # Leemos las imágenes segmentada y solucion
    obtenida = cv.imread(path_obtenida, cv.IMREAD_GRAYSCALE)
    solucion = cv.imread(path_objetivo, cv.IMREAD_GRAYSCALE)

    score = 0
    if obtenida is None:
        print("Error de lectura en imagen {} - IoU = {}".format(path_obtenida, score))
    elif solucion is None:
        print("Error de lectura en imagen {} - IoU = {}".format(path_obtenida, score))
    else:
        # Cálculo IoU:
        intersectionAB = cv.countNonZero(obtenida & solucion)
        unionAB = cv.countNonZero(obtenida | solucion)
        score = intersectionAB / unionAB
        print("Imagen {} - IoU={}".format(path_obtenida, score))

    return score


""" Cálculo del Mean IoU para un grupo de imágenes """
def batch_IoU(path_input):
    meanIoU=0

    # Listar imágenes:
    imgs = [f for f in os.listdir(path_input) if f.endswith('.png')]

    # Recorrer imágenes:
    for img in imgs:

        # Cálculo IoU para imagen actual:
        iou_score = single_IoU(path_input=os.path.join(path_input, img))

        # Acumular resultado:
        meanIoU += iou_score

    # Promedio:
    meanIoU /= len(imgs)
    print("Mean IoU={}".format(meanIoU))

    return


""" Parsear argumentos """
def arguments():
    parser = argparse.ArgumentParser(description = 'Programa para obtener el IoU de un grupo de imágenes')
    parser.add_argument('--modo', '-m', choices=['batch','single'], default='batch')
    parser.add_argument('--input', '-i', type=str, default='input')
    args = parser.parse_args()

    return args

""" Evaluador """
def eval():
    # Argumentos:
    args = arguments()

    # Modos de funcionamiento
    if args.modo == 'single': # Una imagen
        single_IoU(path_input = args.input)
    elif args.modo == 'batch': # Carpeta con imágenes
        batch_IoU(path_input = args.input)

    return


if __name__ == '__main__':
    eval()
